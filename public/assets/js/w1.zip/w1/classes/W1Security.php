<?php defined('MODPATH') or die();

class W1Security extends Kohana_W1Security
{
    // Code
}