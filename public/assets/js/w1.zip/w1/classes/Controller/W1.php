<?php defined('MODPATH') or die();

class Controller_W1 extends Controller_Templates_Office
{
    public function action_confirm()
    {
        $post = $this->request->post();

        $v = Validation::factory($post)
            ->rule('token', 'not_empty')
            ->rule('token', 'Security::check')
            ->rule('WMI_PAYMENT_AMOUNT', 'not_empty')
            ->rule('WMI_PAYMENT_AMOUNT', 'digit')
            ->check();

        if ( ! $v)
            throw new HTTP_Exception_404('Page not found');

        $form = W1::getPaymentForm($post);

        $this->render('w1/confirm', array('form' => $form));
    }
}