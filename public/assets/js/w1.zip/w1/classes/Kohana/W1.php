<?php defined('MODPATH') or die();

/**
 * Class Kohana_W1
 *
 * Сугубо стандартный код от самого WalletOne, моего тут
 * почти ничего нет.. А если и есть, то только говно блять
 *
 * @link http://www.walletone.com/ru/merchant/documentation/
 */
class Kohana_W1
{
    /**
     * Возвращает нам формочку.. И страницу подтверждения, мол
     * Васька, внатуре платишь, или пиздишь?
     *
     * @param array $post
     * @return $this
     */
    final public static function getPaymentForm(array $post)
    {
        $fields = W1Sorter::sortDataFields(array_merge($post, W1Storage::getDefaultsFields()));
        $fields['WMI_SIGNATURE'] = W1Security::createSignature($fields);

        return W1Forms::getConfirmForm($fields);
    }
} // Код взят с сайта W1