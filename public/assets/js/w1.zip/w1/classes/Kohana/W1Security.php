<?php defined('MODPATH') or die();

class Kohana_W1Security
{
    /**
     * Ебанули подпись, ибо нехуй без неё делать.. ругаются,
     * крутые дядьки, когжа нет её :(
     *
     * @param array $fields
     * @return string
     */
    public static function createSignature(array $fields)
    {
        $signature = '';

        foreach ($fields as $value) {
            if (is_array($value)) {
                foreach ($value as $v) {
                    $v = iconv('utf-8', 'windows-1251', $v);
                    $signature .= $v;
                }
            } else {
                $value = iconv('utf-8', 'windows-1251', $value);
                $signature .= $value;
            }
        }

        $md5Hash = md5($signature.W1Storage::getSecretKey());
        $signature = base64_encode(pack('H*', $md5Hash));

        return $signature;
    }
}