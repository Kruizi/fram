<?php defined('MODPATH') or die();

class Kohana_W1Storage
{
    /**
     * Ну тут у меня стандартные поляяяя... Решил их оставить тут..
     * Не, ну на самом деле, нахер их куда-то выносить? Правильно,
     * если нет, то мутите сами... Но во вьюхе это делать не правильно
     *
     * @return array
     * @throws Kohana_Exception
     */
    public static function getDefaultsFields()
    {
        return array(
            'WMI_MERCHANT_ID' => self::getMerchant(),
            'WMI_CURRENCY_ID' => 643,
            'WMI_PAYMENT_NO'  => Auth::instance()->get_user()->id.'_'.rand(0, 15000),
            'WMI_DESCRIPTION' => 'BASE64:'.base64_encode('Пополнение счета в carearning.ru'),
            'MyShopUser'      => Auth::instance()->get_user()->id,
        );
    }

    /**
     * Отдаёт идентификатор кассы
     *
     * @return Kohana_Config_Group
     * @throws Kohana_Exception
     */
    public static function getMerchant()
    {
        return Kohana::$config->load('w1.merchant');
    }

    /**
     * Возвращает секретный ключ магазина
     *
     * @return Kohana_Config_Group
     * @throws Kohana_Exception
     */
    public static function getSecretKey()
    {
        return Kohana::$config->load('w1.secretKey');
    }

}