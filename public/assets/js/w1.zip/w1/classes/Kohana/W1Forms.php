<?php defined('MODPATH') or die();

class Kohana_W1Forms
{
    /**
     * Отдаёт папку в которой хранятся формы
     *
     * @return string
     */
    public static function getFormsPath()
    {
        return '_forms';
    }

    /**
     * Форма для ввода баблишка, на которое хотим пополнить
     * счёт
     *
     * @return View
     */
    public static function getPaymentForm()
    {
        return View::factory('w1/'.self::getFormsPath().'/payment');
    }

    /**
     * Форма для подтверждения платежа, может вызываться
     * только из класса Kohana_W1
     *
     * @param array $fields
     * @param $called
     * @return $this
     * @throws Exception
     */
    public static function getConfirmForm(array $fields, $called)
    {
        if ($called instanceof Kohana_W1)
            throw new Exception('Fuck you bitch!');

        return View::factory('w1/'.self::getFormsPath().'/confirm')
            ->set('fields', $fields);
    }
}