<?php defined('MODPATH') or die();

class Kohana_W1Sorter
{
    /**
     * От души отсортировали все поля, так до сих пор и не
     * понимаю нахер надо :)
     *
     * @param array $fields
     * @return array
     */
    public static function sortDataFields(array $fields)
    {
        foreach ($fields as $name => $val) {
            if (is_array($val)) {
                usort($val, 'strcasecmp');
                $fields[$name] = $val;
            }

            // Сразу отсортируем поле с баблишком, чтобы потом не париться
            // Да, я говнокодер, я признаю.. но тут я очень торопился
            if ($name === 'WMI_PAYMENT_AMOUNT') {
                $fields[$name] = number_format($val, 2, '.', '');
            }
        }

        uksort($fields, 'strcasecmp');
        return $fields;
    }
}