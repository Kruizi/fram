<?php defined('MODPATH') or die();

class W1Forms extends Kohana_W1Forms
{
    // code
}