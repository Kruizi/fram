<?php defined('MODPATH') or die();

class W1Sorter extends Kohana_W1Sorter
{
    // Code
}