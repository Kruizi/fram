<?php defined('MODPATH') or die();

class W1 extends Kohana_W1
{
    // Code
}