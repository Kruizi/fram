<?php defined('MODPATH') or die();

class W1Storage extends Kohana_W1Storage
{
    // Code
}