<?php defined('MODPATH') or die();

/**
 * Роут для работы с W1
 */
Route::set('w1-route', 'balance/<controller>/<action>(/<id>)')
    ->defaults();