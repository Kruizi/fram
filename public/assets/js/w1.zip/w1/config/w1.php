<?php defined('MODPATH') or die();

return array(
    'merchant'  => '126254077392',
    'secretKey' => '3461537a314c4f3859636f42675f4235514e7937713046676b5c79',
);